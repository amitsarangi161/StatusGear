@extends('layouts.account')
@section('content')
<table  class="table" id="resultsTable">
  <tr class="bg-blue">
    <td class="text-center">DEBITOR LEDGER</td>
  </tr>
</table>
<table  class="table table-responsive table-hover table-bordered table-striped">
	<form action="/ledger/debitorledger" method="get">
	<tr>
		<td width="10%"><strong>Select a Users</strong></td>
		<td width="30%">

			<select class="form-control select2" name="vendor" required="">
				<option value="">Select a Vendor</option>
				<option value="ALL" {{ ( Request::get('vendor') == "ALL") ? 'selected' : '' }}>ALL</option>
				@foreach($vendors as $vendor)
				<option value="{{$vendor->id}}" {{ ( $vendor->id == Request::get('vendor')) ? 'selected' : '' }}>{{$vendor->vendorname}}</option>
				@endforeach
				
			</select>
		</td>
		
	
		<td width="10%"><button type="submit" class="btn btn-info">FETCH LEDGER</button></td>
	</tr>
	</form>
	
</table>

@if($alldebitvoucherarr)
<table  class="table table-responsive table-hover table-bordered table-striped datatable1">
	<thead class="bg-navy">
		<tr>
			<td>ID</td>
			<td>VENDOR NAME</td>
			<td>CREDIT</td>
			<td>DEBIT</td>
			<td>BALANCE</td>
		</tr>
	</thead>
	<tbody>
		@php
           $tcr=array();
           $tdr=array();
           $tbal=array();

		@endphp
		@foreach($alldebitvoucherarr as $key=>$value)
		<tr>
			<td>{{++$key}}</td>
			<td>{{$value['vendorname']}}</td>
			<td>{{$tcr[]=$value['cr']}}</td>
			<td>{{$tdr[]=$value['dr']}}</td>
			<td>{{$tbal[]=$value['bal']}}</td>
		</tr>

		@endforeach
	</tbody>
	<tfoot>
		<tr>
			<td colspan="2">Total</td>
			<td>{{array_sum($tcr)}}</td>
			<td>{{array_sum($tdr)}}</td>
			<td>{{array_sum($tbal)}}</td>
			
		</tr>
	</tfoot>
</table>


@endif
@if($debitvouchers)
<button type="button" class="btn btn-success" id="print">Print</button>
<div id="printTable">
<p style="text-align:center;">DEBITOR LEDGER</p>

<table width="100%">
<tbody><tr style="border-bottom:1px solid;text-align: center;background: #383b3e;color: #fff;line-height: 2em;">
<td style="width: 100%;">LEDGER</td>



</tr>


</tbody>
</table>


<table  width="100%">

<tbody>

<tr style="background: #c0c0c0;height: 2.5em;font-size: 1em;border-bottom: 1px black solid; font-weight: bold;">

<td style="width: 10%; text-align:left;">
BILL NO</td>
<td style="width: 10%; text-align:left;">
DATE</td>
<td style="width: 10%; text-align:left;">
STATUS</td>
<td style="width: 10%; text-align:left;">
CREATED_AT</td>
<td style="width: 10%; text-align:right;">
CREDIT</td>
<td style="width: 10%; text-align:right;">
DEBIT</td>
<td style="width: 10%; text-align:right;">
BALANCE</td>

</tr>

@php
  $start=0;
  $totalpaid=0;
  $totalexp=0;

@endphp
@foreach($debitvouchers as $arr)
@php
  
  $start+=$arr['header']['approvalamount'];
  $totalpaid+=$arr['header']['approvalamount'];
@endphp
<tr style="line-height: 2em;font-weight: bold;" class="noexcel">
<tr>
	
	<td style="width: 10%; text-align:left;">{{$arr['header']['billno']}}</td>
	<td style="width: 10%; text-align:left;">{{$arr['header']['billdate']}}</td>
    <td style="width: 10%; text-align:left;">{{$arr['header']['status']}}</td>
	<td style="width: 10%; text-align:left;">{{$arr['header']['created_at']}}</td>
	<td style="width: 10%; text-align:right;">{{$arr['header']['approvalamount']}}</td>
	<td style="width: 10%; text-align:right;">0</td>
	<td style="width: 10%; text-align:right;">{{$start}}</td>
	
</tr>
<tr style="font-weight: bold;border-top: 1px dashed;background: #e8e8e8;line-height: 3em;" class="noexcels">
 @foreach($arr['payments'] as $exp)
@php
  $abc=$start;
  $getexp=$abc-$exp->amount;
  $totalexp+=$exp->amount;
@endphp
<tr style="background-color: #ffb3b3;">
	
	<td style="width: 10%; text-align:left;">*</td>
	<td style="width: 10%; text-align:left;">{{$exp->dateofpayment}}</td>
	<td style="width: 10%; text-align:left;">{{$exp->paymentstatus}}</td>
	<td style="width: 10%; text-align:left;">{{$exp->created_at}}</td>
	<td style="width: 10%; text-align:right;">0</td>
	<td style="width: 10%; text-align:right;">{{$exp->amount}}</td>
	<td style="width: 10%; text-align:right;">{{$getexp}}</td>
	
</tr>
@php
   $abc=$getexp;
   $start=$abc;
@endphp
@endforeach

@endforeach







</tbody>
<tr style="font-weight: bold;border-top: 1px dashed;background: #e8e8e8;line-height: 3em;">
<tfoot>

<tr style="background-color: red;">
	<td style="width: 10%; text-align:left;"></td>
    <td style="width: 10%; text-align:left;"></td>
	<td style="width: 10%; text-align:left;"></td>
	<td style="width: 10%; text-align:left;">TOTAL</td>
	<td style="width: 10%; text-align:right;">{{$totalpaid}}</td>
	<td style="width: 10%; text-align:right;">{{$totalexp}}</td>
	<td style="width: 10%; text-align:right;">{{$start}}</td>
</tr>



</tfoot>

</table>
</div>

@endif
<script type="text/javascript">
	function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('#print').on('click',function(){
printData();
})
</script>

@endsection