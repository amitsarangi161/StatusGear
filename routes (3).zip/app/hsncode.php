<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hsncode extends Model
{
    //
}
