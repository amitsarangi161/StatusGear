@extends('layouts.account')
@section('content')

<table class="table table-responsive table-hover table-bordered table-striped">
	<tr class="bg-blue">
		<td class="text-center">VIEW EXPENSE ENTRY DETAILS</td>
	</tr>
	
</table>
<div class="well">
<table class="table">
	<tr>
		<td><strong>EXPENSE ENTRY ID:</strong></td>
		<td><strong>#{{$expenseentry->id}}</strong></td>
		<td><strong>FOR EMPLOYEE</strong></td>
		<td><strong>{{$expenseentry->for}}</strong></td>
		
	</tr>

	<tr>
		<td><strong>PROJECT NAME :</strong></td>
		<td width="40%"><strong>{{$expenseentry->projectname}}</strong></td>
		<td><strong>FOR CLIENT</strong></td>
		<td><strong>{{$expenseentry->clientname}}</strong></td>
		
	</tr>
	<tr>
		<td><strong>EXPENSE HEAD NAME :</strong></td>
		<td><strong>{{$expenseentry->expenseheadname}}</strong></td>
		<td><strong>PARTICULAR NAME</strong></td>
		<td><strong>{{$expenseentry->particularname}}</strong></td>
		
	</tr>
	<tr>
		<td><strong>VENDOR NAME :</strong></td>
		<td><strong>{{$expenseentry->vendorname}}</strong></td>
		<td><strong>AMOUNT</strong></td>
		<td><strong>{{$expenseentry->amount}}</strong></td>
		
	</tr>
		<tr>
		<td><strong>REMARKS :</strong></td>
		<td><strong>{{$expenseentry->remarks}}</strong></td>
		<td><strong>APPROVED BY</strong></td>
		<td><strong>{{$expenseentry->approvedbyname}}</strong></td>
		
	</tr>
	<tr>
		<td><strong>ENTRY BY</strong></td>
		<td><strong>{{$expenseentry->by}}</strong></td>
		<td><strong>CREATED_AT</strong></td>
		<td><strong>{{$expenseentry->created_at}}</strong></td>
		
	</tr>
	<tr>
		<td><strong>DESCRIPTIONS</strong></td>
		<td><strong>{{$expenseentry->description}}</strong></td>
		<td></td>
		<td></td>
		
	</tr>
	<tr>
		<td><strong>UPLOADED FILE</strong></td>
		 <td>
		 	<a href="{{ asset('/img/expenseuploadedfile/'.$expenseentry->uploadedfile )}}" target="_blank">
		 	<img title="click to view the image" style="height:100px;width:150px;" alt="no uploadedfile" src="{{ asset('/img/expenseuploadedfile/'.$expenseentry->uploadedfile )}}">
		 	<strong>Click Here To View</strong>
		 	</a>
		 </td>
		 <td>
		 	 <a href="{{ asset('/img/expenseuploadedfile/'.$expenseentry->uploadedfile )}}" download>
		 	 	<button class="btn"><i class="fa fa-download"></i> Download</button>
		 	 </a>
		 </td>
	</tr>
	<tr>
		<td><strong>STATUS</strong></td>
		<td><span class="label label-info">{{$expenseentry->status}}</span></td>
	</tr>
</table>

</div>
<table class="table table-responsive table-hover table-bordered table-striped">
	<tr class="bg-blue">
		<td class="text-center">VENDOR DETAILS</td>
	</tr>
	
</table>

<div class="well">
	@if($vendor)
<table class="table">
	<tr>
		<td><strong>VENDOR ID</strong></td>
		<td><strong>#{{$vendor->id}}</strong></td>
		<td><strong>VENDOR NAME</strong></td>
		<td><strong>{{$vendor->name}}</strong></td>
	</tr>

	<tr>
		<td><strong>VENDOR MOBILE</strong></td>
		<td><strong>{{$vendor->mobile}}</strong></td>
		<td><strong>VENDOR DETAILS</strong></td>
		<td><strong>{{$vendor->details}}</strong></td>
	</tr>
	<tr>
		<td><strong>VENDOR ID PROOF</strong></td>
		   <td> <a href="{{ asset('/img/vendor/'.$vendor->vendoridproof )}}" target="_blank">
			<img title="click Here to view Full image" style="height:70px;width:95px;" src="{{ asset('/img/vendor/'.$vendor->vendoridproof )}}"></a>
			
				<a href="{{ asset('/img/vendor/'.$vendor->vendoridproof )}}" download>
		 	 	<button class="btn"><i class="fa fa-download"></i> Download</button>
		 	     </a>
			</td>
		
		<td><strong>VENDOR PHOTO</strong></td>
		<td><a href="{{ asset('/img/vendor/'.$vendor->photo )}}" target="_blank">
		<img title="click Here to view Full image" style="height:70px;width:95px;" src="{{ asset('/img/vendor/'.$vendor->photo )}}"> </a>
		
			<a href="{{ asset('/img/vendor/'.$vendor->photo )}}" download>
		 	 	<button class="btn"><i class="fa fa-download"></i> Download</button>
		 	 </a>
		</td>
	   
	</tr>
	<tr>
		<td><strong>VENDOR ADDED BY</strong></td>
		<td><strong>{{$vendor->name}}</strong></td>
		<td><strong>CREATED AT</strong></td>
		<td><strong>{{$vendor->created_at}}</strong></td>
	</tr>
</table>
@endif
</div>

@endsection