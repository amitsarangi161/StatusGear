@extends('layouts.account')
@section('content')
<style type="text/css">
	.mybtn{width: 250px;}

	.b {
    white-space: nowrap; 
    width: 150px; 
    overflow: hidden;
    text-overflow: ellipsis; 
   
}
</style>

@php
$paid=$paidamounts->sum('amount');

$bal=$requisitionheader->approvalamount-$paid;
@endphp
<table class="table table-responsive table-hover table-bordered table-striped">
	 <tr class="bg-blue">
	 	<td class="text-center">REQUISITION DETAIlS</td>
	 </tr>
</table>

<div class="well" style="font-size: 20px;background-color: violet;">
  <div class="table-responsive">
    <table class="table">
      <tr>

      <td><strong>TOTAL PAID AMOUNT TILL DATE :</strong>  {{$totalamt}}</td>
      <td><strong>TOTAL EXPENSE TILL DATE :</strong> {{$totalamtentry}}</td>
      <td><strong>BALANCE AMOUNT :</strong> {{$bal1}}</td>
      </tr>
      
    </table>
    
  </div>
  
</div>
	



<div class="well">
	<div class="table-responsive" >
	<table class="table" style="background-color: silver;">
		<tr>
			<td><strong>REQUISITION ID</strong></td>
			<td>#{{$requisitionheader->id}}</td>
			<td><strong>PROJECT NAME</strong></td>
			@if($requisitionheader->projectname!='')
			<td width="40%">{{$requisitionheader->projectname}}</td>
			@else
            <td>OTHERS</td>
			@endif
		</tr>
         <tr>
			<td><strong>NAME</strong></td>
			<td>{{$requisitionheader->employee}}</td>
			<td><strong>AUTHOR</strong></td>
			<td>{{$requisitionheader->author}}</td>
		 </tr>
		  <tr>
			<td><strong>TOTAL AMOUNT</strong></td>
			<td>{{$requisitionheader->totalamount}}</td>
			<td><strong>APPROVAL AMOUNT</strong></td>
			<td>{{$requisitionheader->approvalamount}}</td>
		  </tr>
		  <tr>
			<td><strong>TOTAL AMOUNT PAID</strong></td>
			<td><span class="label label-primary">{{$paid}}</span></td>
			<td><strong>BALANCE AMOUNT</strong></td>
			<td><span class="label label-danger">{{$bal}}</span></td>
		  </tr>
		  <tr>
			<td><strong>APPROVED BY</strong></td>
			@if($requisitionheader->approvedby=='')
			   <td>NOT APPROVED</td>
			@else
              <td>{{$requisitionheader->approvedby}}</td>
			@endif
			
			<td><strong>STATUS</strong></td>
			<td>{{$requisitionheader->status}}</td>
			
		  </tr>
      
       <tr>
        <td><strong>DATE FROM</strong></td>
        <td><strong class="bg-navy">{{$requisitionheader->datefrom}}</strong></td>
        <td><strong>DATE TO</strong></td>
        <td><strong class="bg-navy">{{$requisitionheader->dateto}}</strong></td>
      </tr>

		  <tr>
			
			<td><strong>CREATED_AT</strong></td>
			<td>{{$requisitionheader->created_at}}</td>
			<td><strong>DESCRIPTION</strong></td>
			<td>{{$requisitionheader->description}}</td>
		  </tr>
		
	</table>
	</div>
</div>





<div class="well">
   <div class="table-responsive" >
     <div  class="container-tb tableContainer">
	<table class="table table-responsive table-hover table-bordered table-striped">

		<thead class="bg-navy">
			<tr>
				<th>SL_NO</th>
				<th>EXPENSE HEAD</th>
				<th>PARTICULAR</th>
        <th>DESCRIPTION</th>
				<th>PAY TO</th>
				<th>AMOUNT</th>
				<th>APPROVED AMOUNT</th>
				<th>REMARKS</th>
				<th>STATUS</th>
				
				
			</tr>
		</thead>
		<tbody>
			@foreach($requisitions as $key=>$requisition)
			<tr>
				<td>{{$key+1}}</td>
				<td>{{$requisition->expenseheadname}}</td>
				<td>{{$requisition->particularname}}</td>
        <td>{{$requisition->description}}</td>
				<td>{{$requisition->payto}}</td>
				<td>{{$requisition->amount}}</td>
				<td>{{$requisition->approvedamount}}</td>
			   <td><p class="b" title="{{$requisition->remarks}}">   {{$requisition->remarks}}</p></td>
				<td>{{$requisition->approvestatus}}</td>
				
				

			</tr>

			@endforeach
		</tbody>
		<tfoot>
			<tr class="bg-gray">
				<td></td>
				<td></td>
        <td></td>
				<td></td>
				<td><strong>TOTAL AMOUNT</strong></td>
				<td><strong>Rs.{{$requisitions->sum('amount')}}</strong></td>
				<td><strong>Rs.{{$requisitions->sum('approvedamount')}}</strong></td>
				<td></td>
				<td></td>
				
			</tr>
		</tfoot>
	</table>
</div>
	</div>
</div>

<table class="table table-responsive table-hover table-bordered table-striped">
	 <tr class="bg-blue">
	 	<td class="text-center">VIEW PAYMENTS</td>
	 </tr>
</table>
<div class="table-responsive" >
<table class="table table-responsive table-hover table-bordered table-striped">

		<thead class="bg-navy">
			<tr>
				<th>SL_NO</th>
				<th>AMOUNT</th>
				<th>PAYMENT METHOD</th>
        <th>PAYMENT STATUS</th>
        <th>DATE OF PAYMENT</th>
				<th>TRANSACTION ID</th>
				<th>REMARKS</th>
				<th>CREATED_AT</th>
				
				
				
			</tr>
		</thead>
		<tbody>
			@if($paidamounts)
			@foreach($paidamounts as $key=>$paidamount)
			<tr>
				<td>{{$key+1}}</td>
				<td>{{$paidamount->amount}}</td>
				<td>{{$paidamount->paymenttype}}</td>
        <td>{{$paidamount->paymentstatus}}</td>
        <td>{{$paidamount->dateofpayment}}</td>
				<td>{{$paidamount->transactionid}}</td>
				<td>{{$paidamount->remarks}}</td>
				<td>{{$paidamount->created_at}}</td>
				

			</tr>
             
			@endforeach
			@else
             <tr>
             	<td class="text-center">NO PAYMENTS DETAILS</td>
             </tr>
			@endif
		</tbody>
		<tfoot>
			<tr class="bg-gray">
				<td>TOTAL APPROVAL AMOUNT</td>
				<td><strong>Rs.{{$requisitions->sum('approvedamount')}}</strong></td>
				<td>TOTAL PAID AMOUNT</td>
				<td><strong>Rs.{{$paidamounts->sum('amount')}}</strong></td>
				<td>BALANCE</td>
				<td>Rs.{{$requisitions->sum('approvedamount')-$paidamounts->sum('amount')}}</td>
        <td></td>
        <td></td>
			</tr>
		</tfoot>
		
	</table>
</div>
<div class="well">
	<div class="table-responsive" >
	<table class="table">
		<tr>
			@if($bal<=1)

			
               
               <td>
               	<form action="/markascompleterequisition/{{$requisitionheader->id}}" method="post">
               		{{csrf_field()}}
               		<button class="btn btn-success btn-lg center-block mybtn" type="submit">MARK AS COMPLETED</button>
               	</form>
               </td>

             	 <td ><button type="button" disabled="" class="btn btn-danger btn-lg center-block mybtn">CANCEL THIS REQUISITION</button></td>
             	 <td><button type="button" disabled="" class="btn btn-info btn-lg center-block mybtn">PAY</button></td>
      
			@else
		  
              <td>	<button disabled="" class="btn btn-success btn-lg center-block mybtn" type="button" title="first clear all the amount.">MARK AS COMPLETED</button></td> 

                 @if($paid>0)
                     <td ><button type="button" disabled="" class="btn btn-danger btn-lg center-block mybtn">CANCEL THIS REQUISITION</button></td>
                 @else
                  <td ><button type="button" onclick="openapprovalmodal();" class="btn btn-danger btn-lg center-block mybtn">CANCEL THIS REQUISITION</button></td>

                 @endif
               	
			<td><button type="button" onclick="openpaymodal();" class="btn btn-info btn-lg center-block mybtn">PAY</button></td>

			

			@endif
</tr>
           
			
		
		
	</table>
</div>
	</div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">CANCEL THIS REQUISITION</h4>
        </div>
        <div class="modal-body">
        	<form action="/changependingstatustocancel/{{$requisitionheader->id}}" method="post">
        		{{csrf_field()}}
          <table class="table">
          	<tr>
          		<td><strong>TOTAL AMOUNT</strong></td>
          		<td>
          			<input type="text" class="form-control"  value="{{$requisitionheader->totalamount}}" readonly>
          		</td>
          	</tr>
          	<tr>
          		<td><strong>SELECT A ACTION</strong></td>
          		<td>
          			<select class="form-control" onchange="removerequired();" id="status" name="status" required="">
          				
          			
          				<option value="CANCELLED">CANCELLED</option>
          				
          			</select>
          		</td>
          	</tr>
    
          	<tr>
          		<td><strong>REMARKS</strong></td>
          		<td>
          			<textarea name="remarks" class="form-control"></textarea>
          		</td>
          	</tr>
          	<tr>
          		<td colspan="2"><button type="submit" class="btn btn-success">CANCEL</button></td>
          	</tr>
          
          </table>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>



  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">PAY FOR REQUISITION</h4>
        </div>
        <div class="modal-body">
        	<form action="/payrequisition/{{$requisitionheader->id}}" method="post">
        		{{csrf_field()}}
          <table class="table">
          	<tr>
          		<td><strong>APPROVED AMOUNT</strong></td>
          		<td>
          			<input type="text" class="form-control"  value="{{$requisitionheader->approvalamount}}" readonly>
          		</td>
          	</tr>
          	<tr>
          		<td><strong>PAID AMOUNT</strong></td>
          		<td>
          			<input type="text" class="form-control"  value="{{$paid}}" readonly>
          		</td>
          	</tr>
          	<tr>
          		<td><strong>PAYMENT TYPE</strong></td>
          		<td>
          			<select class="form-control" name="paymenttype" onchange="getbank(this.value);" required="">
          				<option value="">SELECT A PAYMENT TYPE</option>
          				<option value="ONLINE PAYMENT">ONLINE PAYMENT</option>
          				<option value="CASH">CASH</option>
          			</select>
          		</td>
          	</tr>
          	<tr style="display: none;" id="showbank">
          		<td><strong>SELECT BANK</strong></td>
          		<td>
          			<select class="form-control" name="bankid" id="reqbank">
          				<option value="">Select a Bank</option>
          				@foreach($banks as $bank)
                          <option value="{{$bank->id}}">{{$bank->bankname}}</option>
          				@endforeach
          				
          			</select>
          		</td>
          	</tr>
          	<tr>
          		<td><strong>AMOUNT</strong></td>
          		<td>
          			<input type="number" name="amount"  class="form-control" id="amt1" autocomplete="off" required="">
          		</td>
          	</tr>
          	<tr>
          		<td><strong>BALANCE AMOUNT</strong></td>
          		<td>
          			<input type="text" class="form-control"  value="{{($requisitionheader->approvalamount-$paid)}}" id="balanceamt" readonly>
          		</td>
          	</tr>
    
          	<tr>
          		<td><strong>REMARKS</strong></td>
          		<td>
          			<textarea name="remarks" class="form-control"></textarea>
          		</td>
          	</tr>
          	 <tr>
        <td colspan="2" style="text-align: center;font-size:15px;"> <p id="errormsg" style="color: red;"></p></td>
      </tr>
          	<tr>
          		<td colspan="2"><button type="submit" id="subbutton" class="btn btn-success">SUBMIT</button></td>
          	</tr>
          
          </table>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<script type="text/javascript">
	function openapprovalmodal() {
		 $("#myModal").modal('show');
	}
function openpaymodal() {
		 $("#myModal1").modal('show');
	}

	function removerequired()
	{
		var status=$("#status").val();
		

		if(status=='CANCELLED')
		{

			$('#approvalamount').prop('required',false);
		}
		else
		{
			$("#approvalamount").prop('required',true);
		}
	}
  function getbank(type)
  {
  	if(type=='CASH')
  	{
  		$("#showbank").hide();
  		$('#reqbank').prop('required',false);
  	}
  	else
  	{
  		$("#showbank").show();
  		$('#reqbank').prop('required',true);
  	}

  }
	$("#amt1").bind("keyup change", function(e) {
    var s1={{($requisitionheader->approvalamount-$paid)}};
    var s2=$("#amt1").val();
    $("#balanceamt").val(s1-s2);

    var bal=$("#balanceamt").val();

     if(bal<0)
      {
         $("#subbutton").attr("disabled", true);
         $("#errormsg").html("Your Amount Must be less than balance amount");
      }
      else
      {
         $("#subbutton").removeAttr("disabled");
         
         $("#errormsg").html("");
      }
});


</script>

@endsection