Hello <i>{{$name}}</i>,
      <p>Your Registartion For stepltest.com has been Confirmed.</p>
 
<p><u>Your login Details</u></p>
 
<div>
<p><b>User Name:</b>&nbsp;{{ $uname}}</p>
<p><b>email:</b>&nbsp;{{$email}</p>
<p><b>password:</b>&nbsp;{{$password}</p>
</div>
 

  <p>You can use either email or useranme as userid to login.</p>
 
Thank You,
<br/>
<i>Subudhi Tecnoengineers</i>