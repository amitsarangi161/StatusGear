<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class locationsetup extends Model
{
    //
}
