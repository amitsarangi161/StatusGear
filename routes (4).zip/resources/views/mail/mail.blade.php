Hello <i>{{$name}}</i>,
      <p>You have been successfully registered!(stepltest(dot)(com))</p>
 
 
<p><u>Your Login Credentials</u></p>
 
<div>
<p><b>User Name:</b>&nbsp;{{$uname}}</p>
<p><b>email:</b>&nbsp;{{$email}}</p>
<p><b>password:</b>&nbsp;{{$password}}</p>
</div>
<p></p> 

  
 
Thank You,
<br/>
<i>Subudhi Tecnoengineers</i>