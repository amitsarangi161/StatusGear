<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class testimage extends Model
{
    //
}
