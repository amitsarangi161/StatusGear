<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class requisitionheader extends Model
{
    //
}
