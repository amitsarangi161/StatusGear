<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class crvoucheritem extends Model
{
    //
}
