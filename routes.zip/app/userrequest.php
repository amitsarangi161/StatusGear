<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userrequest extends Model
{
    //
}
