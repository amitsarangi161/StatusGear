<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Associatepartner extends Model
{
    //
}
