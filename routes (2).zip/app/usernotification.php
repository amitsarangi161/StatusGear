<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usernotification extends Model
{
    //
}
