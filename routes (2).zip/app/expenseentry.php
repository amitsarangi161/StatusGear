<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class expenseentry extends Model
{
    //
}
